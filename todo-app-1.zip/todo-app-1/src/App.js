import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./components/Home";
import ViewTodos from "./components/ViewTodos";
import Navbar from "./components/Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

const App = () => {
	const [todos, setTodos] = useState([]);

	// Load todos from localStorage when component mounts
	useEffect(() => {
		const storedTodos = JSON.parse(localStorage.getItem("todos")) || [];
		setTodos(storedTodos);
	}, []);

	// Save todos to localStorage whenever todos state changes
	useEffect(() => {
		localStorage.setItem("todos", JSON.stringify(todos));
	}, [todos]);

	const addTodo = (newTodo) => {
		setTodos((prevTodos) => [...prevTodos, newTodo]);
	};

	const deleteTodo = (index) => {
		setTodos((prevTodos) => prevTodos.filter((_, i) => i !== index));
	};

	return (
		<Router>
			<Navbar />
			<Routes>
				<Route path="/" element={<Home addTodo={addTodo} />} />
				<Route
					path="/view-todos"
					element={<ViewTodos todos={todos} deleteTodo={deleteTodo} />}
				/>
			</Routes>
		</Router>
	);
};

export default App;
