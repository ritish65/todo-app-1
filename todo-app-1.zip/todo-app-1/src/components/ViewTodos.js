import React from "react";

const ViewTodos = ({ todos, deleteTodo }) => {
	return (
		<div className="container mt-5">
			<h2 className="text-center mb-4">View Todos</h2>
			<div className="row">
				{todos.length === 0 ? (
					<div className="col-12 text-center">
						<p>No todos available</p>
					</div>
				) : (
					todos.map((todo, index) => (
						<div className="col-md-6 col-lg-4 mb-4" key={index}>
							<div className="card shadow-sm">
								<div className="card-body">
									<p className="card-text">{todo}</p>
									<button
										className="btn btn-danger btn-sm float-right"
										onClick={() => deleteTodo(index)}
									>
										Delete
									</button>
								</div>
							</div>
						</div>
					))
				)}
			</div>
		</div>
	);
};

export default ViewTodos;
