import React, { useState, useRef } from "react";

const Home = ({ addTodo }) => {
	const [todo, setTodo] = useState("");
	const [error, setError] = useState("");
	const [success, setSuccess] = useState("");
	const textareaRef = useRef(null);

	const handleSubmit = (e) => {
		e.preventDefault();
		if (todo.trim() === "") {
			setError("Todo cannot be empty");
			setSuccess("");
		} else {
			addTodo(todo);
			setTodo("");
			setError("");
			setSuccess("Todo added successfully!");

			// Reset textarea size
			if (textareaRef.current) {
				textareaRef.current.style.height = "auto";
			}

			// Hide the success message after 3 seconds
			setTimeout(() => setSuccess(""), 3000);
		}
	};

	const handleKeyDown = (e) => {
		if (e.key === "Enter") {
			e.preventDefault(); // Prevent the default behavior of adding a new line
			handleSubmit(e); // Trigger the form submission
		}
	};

	const handleChange = (e) => {
		setTodo(e.target.value);
		if (error) {
			setError(""); // Clear error when typing starts
		}
	};

	return (
		<div
			className="container d-flex justify-content-center align-items-center"
			style={{ height: "100vh", marginTop: "-10%" }}
		>
			<div
				className="card p-4 shadow"
				style={{ maxWidth: "500px", width: "100%" }}
			>
				<h2 className="text-center mb-4">Add Todo</h2>
				<form onSubmit={handleSubmit}>
					<div className="form-group">
						<textarea
							ref={textareaRef}
							type="text"
							className="form-control"
							placeholder="Enter todo"
							value={todo}
							onChange={handleChange} // Use handleChange to manage input and errors
							onKeyDown={handleKeyDown} // Listen for the Enter key press
							style={{
								height: "auto",
								minHeight: "50px",
								resize: "none",
								overflow: "hidden",
							}}
							rows="1"
							onInput={(e) => {
								e.target.style.height = "auto";
								e.target.style.height = e.target.scrollHeight + "px";
							}}
						/>
						{error && <small className="text-danger">{error}</small>}
					</div>
					<div className="d-flex justify-content-center">
						<button type="submit" className="btn btn-primary mt-3">
							Add Todo
						</button>
					</div>
				</form>
				{success && <div className="alert alert-success mt-3">{success}</div>}
			</div>
		</div>
	);
};

export default Home;
